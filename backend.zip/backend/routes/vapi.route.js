import {Router} from "express";
import {sendInformation} from "../controllers/vapi.controller.js";

const vapiRouter = Router();

vapiRouter.get('/generate', (req, res) => res.send({success: true, data:"Hello"}));
vapiRouter.post('/generate', sendInformation);

export default vapiRouter;
