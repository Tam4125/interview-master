
import mongoose from "mongoose";
import Interview from "../models/interview.model.js";
import {GoogleGenAI} from "@google/genai";
import {GOOGLE_GEMINI_API_KEY} from "../config/env.js";

export const sendInformation = async (req, res, next) => {
    const {type, role, level, techstack, interval, userid} = req.body;

    const session = await mongoose.startSession();
    session.startTransaction();

    try {
        const ai = new GoogleGenAI({apiKey: GOOGLE_GEMINI_API_KEY});
        const {text:questions} = await ai.models.generateContent({
            model: "gemini-2.0-flash",
            contents: `Prepare questions for a job interview.
                    The job role is ${role}.
                    The job experience level is ${level}.
                    The tech stack used in the job is: ${techstack}.
                    The focus between behavioural and technical questions should lean towards: ${type}.
                    The expected time limit required is: ${interval}.
                    Please return only the questions, without any additional text.
                    The questions are going to be read by a voice assistant so do not use "/" or "*" or any other special characters which might break the voice assistant.
                    Return the questions formatted like this:
                    ["Question 1", "Question 2", "Question 3"]`
        });

        const interview = {
            type: type,
            role: role,
            level: level,
            techstack: techstack.split(","),
            interval: interval,
            questions: JSON.parse(questions),
            userId: userid,
            finished: false,
        };

        const newInterview = await Interview.create([interview], {session});
        await session.commitTransaction();
        session.endSession();

        res.status(200).json({success: true, message: 'Interview successfully recorded', data: newInterview[0]});

    } catch (error){
        await session.abortTransaction();
        session.endSession();
        next(error);
    }

}